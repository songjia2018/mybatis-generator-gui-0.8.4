# mybatis-generator-gui
可视化mybatis生成工具，需要支持其他数据库的可以提交PR

## 支持数据库
+ [x] MySQL

## License
MIT

## 接下来
+ [ ] 使用JavaFx重构
+ [ ] 支持更多数据库

## 我的博客
[每天进步一点点](https://www.ddhigh.com)
